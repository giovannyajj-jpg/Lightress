// Observador para animar elementos cuando aparecen en pantalla
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('show');
        }
    });
}, {
    threshold: 0.1
});

// Elementos que se animaran
document.querySelectorAll('h1, h2, h3, p, nav, plan-card, section, feature-item').forEach(el => {
    el.classList.add('hidden');
    observer.observe(el);
});

// Menu hamburguesa
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
});

// uptime
let contador = 0.00;
const elementoContador = document.getElementById('contador');
let intervalo;

function actualizarContador() {
  if (contador >= 99.99) {
    elementoContador.textContent = '99.99';
    clearInterval(intervalo);
  } else {
    contador += 0.1;
    elementoContador.textContent = contador.toFixed(2);
  }
}

intervalo = setInterval(actualizarContador, 1); // incrementa cada 1ms

// Fin del codigo js