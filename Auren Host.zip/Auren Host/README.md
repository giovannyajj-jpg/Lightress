# Instrucciones para desaroolladores

## CSS

El css con el que cuenta la web estanecho por mi e dejado comentarios para que puedan entender para que es cada cosa en las variables de los colorese especificado para que se usa (si no especifique es pq es algo mas especifico).
Los colores estan inspirados en el logo, las animaciones del css son basicas si deceas puedes mejorarla pero tengan en cuenta que el js tambien afecta en la animacion.

### HTML

Todos los archivos html tienen sus meta datos y links listo pero si deseas cambiar o eliminar alguno ten encuenta que puede afectar como se ve la pagina, el heads de todos los archivos son iguales y no recomiendo tocarlo tanto.
Tambien el footer de cada archivo es igual pero como digo no recomiendo tocarlo mucho ya que afectaria como se ve la pagina pero si desas modificarlo puedes hacerlo.

#### JS

De esto no hay mucho que hablar es un codigo corto pero si es bastante mejorable ya que no se mucho de js, en ese js esta el menu de hamburgesa y una suave animacion no es mucho la verdad.

##### Sitemap y Robots

Para los que no saben estos archivos son los que optimizan las busqueda en el navegador no recomiendo tocar para los que no saben pero si sabes y lo puedes mejorar tienes via libre.

###### NOTA

Esta es una modificasion de mi anterior web "Nuvon Host" esta completamente mejorada y cambia en lo que es animacion, colores, rendimiento en los buscadores y apezar de ser una web estatica sin tanta cosa es una buena web muchas gracias por tomarse el tiempo de leer.

###### Utilidades

 **base de datos**

<li><i class="fas fa-database"></i> <b>Base de Datos:</b> 1</li>

**conponentes**

Ubicación: Miami FL, Estados UnidosCPU: AMD Ryzen 9 9900X @ 4.3 - 5.6GHzRAM: DDR5Almacenamiento: SSD NVMeRed: 1 Gb/sProtección Anti-DDoS: Incluida

**backup**

<li><i class="fas fa-save"></i> <b>Backup:</b> 2</li>

